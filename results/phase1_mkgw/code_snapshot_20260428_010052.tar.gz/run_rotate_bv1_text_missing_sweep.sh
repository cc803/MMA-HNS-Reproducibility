#!/usr/bin/env bash
set -euo pipefail

PYTHON_EXE="${PYTHON_EXE:-python}"

run_step() {
    local label="$1"
    shift

    echo "==> ${label}"
    echo "${PYTHON_EXE} $*"
    "${PYTHON_EXE}" "$@"
    echo "<== Completed: ${label}"
}

run_step "B-v1 retrieval missing-text | inject_text_missing_rate=0.1" \
    train_dhns_rotate.py \
    --dataset MKG-Y \
    --seed 0 \
    --use-retrieval-missing-text \
    --retrieval-topk 5 \
    --retrieval-pool-size 512 \
    --retrieval-mix-weight 0.25 \
    --inject-text-missing-rate 0.1 \
    --subset-eval \
    --checkpoint-path ./checkpoint/rotate_bv1_inject_text01_seed0.ckpt

run_step "B-v1 retrieval missing-text | inject_text_missing_rate=0.3" \
    train_dhns_rotate.py \
    --dataset MKG-Y \
    --seed 0 \
    --use-retrieval-missing-text \
    --retrieval-topk 5 \
    --retrieval-pool-size 512 \
    --retrieval-mix-weight 0.25 \
    --inject-text-missing-rate 0.3 \
    --subset-eval \
    --checkpoint-path ./checkpoint/rotate_bv1_inject_text03_seed0.ckpt

run_step "B-v1 retrieval missing-text | inject_text_missing_rate=0.5" \
    train_dhns_rotate.py \
    --dataset MKG-Y \
    --seed 0 \
    --use-retrieval-missing-text \
    --retrieval-topk 5 \
    --retrieval-pool-size 512 \
    --retrieval-mix-weight 0.25 \
    --inject-text-missing-rate 0.5 \
    --subset-eval \
    --checkpoint-path ./checkpoint/rotate_bv1_inject_text05_seed0.ckpt
