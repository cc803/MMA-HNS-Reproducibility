import argparse
import json
import os
import subprocess
import sys


SETTINGS = [
    {
        "name": "hard_mask",
        "label": "Hard Mask",
        "extra_args": ["--use-missing-mask"],
        "checkpoint_path": "./checkpoint/rotate_mask_mkgw_seed0.ckpt",
    },
    {
        "name": "soft_missing_text",
        "label": "Soft Missing-Text Token",
        "extra_args": ["--use-soft-missing-text"],
        "checkpoint_path": "./checkpoint/rotate_softmissing_mkgw_seed0.ckpt",
    },
]

SUMMARY_SPLITS = [
    ("overall", "Overall"),
    ("head_or_tail_missing_text", "Head/Tail Missing Text"),
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run MKG-W seed=0 comparison for RotatE hard mask vs soft missing-text token."
    )
    parser.add_argument("--dataset", type=str, default="MKG-W")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--train-times", type=int, default=None)
    return parser.parse_args()


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    if split_name not in subset_metrics:
        raise KeyError(f"Missing subset metrics for '{split_name}'")
    return subset_metrics[split_name]


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: ") :])
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def print_summary(results):
    print("\nMKG-W seed=0 comparison:")
    print("| Setting | Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---|---|---:|---:|---:|---:|---:|")
    for result in results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            print(
                f"| {result['setting_label']} | {split_label} | {metrics['mrr']:.6f} | {metrics['mr']:.6f} | "
                f"{metrics['hit10']:.6f} | {metrics['hit3']:.6f} | {metrics['hit1']:.6f} |"
            )


def main():
    args = parse_args()
    results = []

    for setting in SETTINGS:
        command = [
            args.python_exe,
            "train_dhns_rotate.py",
            "--dataset",
            args.dataset,
            "--seed",
            str(args.seed),
            "--subset-eval",
            "--checkpoint-path",
            setting["checkpoint_path"],
        ]
        command.extend(setting["extra_args"])
        if args.train_times is not None:
            command.extend(["--train-times", str(args.train_times)])

        result_payload = run_command(f"{setting['label']} | dataset={args.dataset} | seed={args.seed}", command)
        result_payload["setting_name"] = setting["name"]
        result_payload["setting_label"] = setting["label"]
        results.append(result_payload)

    print_summary(results)


if __name__ == "__main__":
    main()
