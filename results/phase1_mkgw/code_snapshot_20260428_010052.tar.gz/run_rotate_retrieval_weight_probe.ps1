param(
    [string]$PythonExe = "python"
)

$ErrorActionPreference = "Stop"

function Run-Step {
    param(
        [string]$Label,
        [string[]]$Args
    )

    Write-Host "==> $Label" -ForegroundColor Cyan
    Write-Host "$PythonExe $($Args -join ' ')" -ForegroundColor DarkGray
    & $PythonExe @Args
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Label"
    }
    Write-Host "<== Completed: $Label" -ForegroundColor Green
}

Run-Step -Label "Retrieval missing-text | mix_weight=0.1" -Args @(
    "train_dhns_rotate.py",
    "--dataset", "MKG-Y",
    "--seed", "0",
    "--use-retrieval-missing-text",
    "--retrieval-pool-size", "512",
    "--retrieval-mix-weight", "0.1",
    "--subset-eval",
    "--checkpoint-path", "./checkpoint/rotate_retrieval_w01.ckpt"
)

Run-Step -Label "Retrieval missing-text | mix_weight=0.25" -Args @(
    "train_dhns_rotate.py",
    "--dataset", "MKG-Y",
    "--seed", "0",
    "--use-retrieval-missing-text",
    "--retrieval-pool-size", "512",
    "--retrieval-mix-weight", "0.25",
    "--subset-eval",
    "--checkpoint-path", "./checkpoint/rotate_retrieval_w025.ckpt"
)

Run-Step -Label "Retrieval missing-text | mix_weight=0.5" -Args @(
    "train_dhns_rotate.py",
    "--dataset", "MKG-Y",
    "--seed", "0",
    "--use-retrieval-missing-text",
    "--retrieval-pool-size", "512",
    "--retrieval-mix-weight", "0.5",
    "--subset-eval",
    "--checkpoint-path", "./checkpoint/rotate_retrieval_w05.ckpt"
)
