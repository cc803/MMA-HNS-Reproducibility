import argparse
import csv
import json
import os
import subprocess
import sys


MISSING_SAMPLE_WEIGHTS = [1.0, 1.25, 1.5]

SUMMARY_SPLITS = [
    ("overall", "overall"),
    ("head_or_tail_missing_text", "head_or_tail_missing_text"),
    ("head_or_tail_injected_missing_text", "head_or_tail_injected_missing_text"),
    ("head_or_tail_both_have_text", "head_or_tail_both_have_text"),
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run the minimal RotatE missing-sample-weight sweep on MKG-Y with injected text missing rate 30%."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--inject-text-missing-rate", type=float, default=0.3)
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--train-times", type=int, default=None)
    parser.add_argument(
        "--output-csv",
        type=str,
        default="./results/rotate_mkgy_missing_sample_weight_sweep_seed0_inject30.csv",
    )
    return parser.parse_args()


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    return subset_metrics.get(split_name)


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: "):])
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def build_rows(results):
    rows = []
    for result in results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            if metrics is None:
                continue
            rows.append(
                {
                    "model": "RotatE",
                    "missing_sample_weight": f"{result['missing_sample_weight']:.2f}",
                    "seed": result["seed"],
                    "split": split_label,
                    "MRR": f"{metrics['mrr']:.6f}",
                    "MR": f"{metrics['mr']:.6f}",
                    "Hit@10": f"{metrics['hit10']:.6f}",
                    "Hit@3": f"{metrics['hit3']:.6f}",
                    "Hit@1": f"{metrics['hit1']:.6f}",
                }
            )
    return rows


def write_csv(rows, output_csv):
    output_dir = os.path.dirname(output_csv)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    with open(output_csv, "w", encoding="utf-8", newline="") as fout:
        writer = csv.DictWriter(
            fout,
            fieldnames=["model", "missing_sample_weight", "seed", "split", "MRR", "MR", "Hit@10", "Hit@3", "Hit@1"],
        )
        writer.writeheader()
        writer.writerows(rows)


def print_summary(rows, output_csv):
    print("\nMKG-Y missing-sample-weight sweep:")
    print("| model | missing_sample_weight | seed | split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---|---:|---:|---|---:|---:|---:|---:|---:|")
    for row in rows:
        print(
            f"| {row['model']} | {row['missing_sample_weight']} | {row['seed']} | {row['split']} | "
            f"{row['MRR']} | {row['MR']} | {row['Hit@10']} | {row['Hit@3']} | {row['Hit@1']} |"
        )
    print(f"\nCSV saved to: {output_csv}")


def main():
    args = parse_args()
    results = []

    for missing_sample_weight in MISSING_SAMPLE_WEIGHTS:
        checkpoint_path = (
            "./checkpoint/rotate_mkgy_softtoken_inject30_seed0_missingweight_"
            + str(missing_sample_weight).replace(".", "p")
            + ".ckpt"
        )
        command = [
            args.python_exe,
            "train_dhns_rotate.py",
            "--dataset",
            args.dataset,
            "--seed",
            str(args.seed),
            "--inject-text-missing-rate",
            str(args.inject_text_missing_rate),
            "--text-mode",
            "soft_token",
            "--missing-sample-weight",
            str(missing_sample_weight),
            "--subset-eval",
            "--checkpoint-path",
            checkpoint_path,
        ]
        if args.train_times is not None:
            command.extend(["--train-times", str(args.train_times)])

        result_payload = run_command(
            f"missing_sample_weight={missing_sample_weight:.2f} | dataset={args.dataset} | inject_text_missing={args.inject_text_missing_rate:.0%} | seed={args.seed}",
            command,
        )
        results.append(result_payload)

    rows = build_rows(results)
    write_csv(rows, args.output_csv)
    print_summary(rows, args.output_csv)


if __name__ == "__main__":
    main()
