#!/usr/bin/env bash
set -euo pipefail

PYTHON_EXE="${1:-python}"

run_step() {
  local label="$1"
  shift
  echo "==> ${label}"
  echo "${PYTHON_EXE} $*"
  "${PYTHON_EXE}" "$@"
  echo "<== Completed: ${label}"
}

run_step "Debug masking run 1" \
  train_dhns.py \
  --dataset MKG-Y \
  --seed 0 \
  --use-missing-mask \
  --debug-masking \
  --debug-mask-batches 3 \
  --checkpoint-path ./checkpoint/debug_mask.ckpt

run_step "Debug masking run 2" \
  train_dhns.py \
  --dataset MKG-Y \
  --seed 0 \
  --use-missing-mask \
  --debug-masking \
  --debug-mask-batches 3 \
  --checkpoint-path ./checkpoint/debug_mask.ckpt

run_step "Subset evaluation run" \
  train_dhns.py \
  --dataset MKG-Y \
  --seed 0 \
  --use-missing-mask \
  --subset-eval \
  --checkpoint-path ./checkpoint/distmult_mask_seed0.ckpt
