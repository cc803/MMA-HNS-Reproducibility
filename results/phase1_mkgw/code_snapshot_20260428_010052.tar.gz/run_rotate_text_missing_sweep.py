import argparse
import json
import os
import statistics
import subprocess
import sys


PRECOMPUTED_SEED0_MKGY = {
    0.1: {
        "hard_mask": {
            "overall": {"mrr": 0.365544, "mr": 1676.761},
            "head_or_tail_missing_text": {"mrr": 0.331332, "mr": 2183.515},
        },
        "soft_missing_text": {
            "overall": {"mrr": 0.371665, "mr": 1310.283},
            "head_or_tail_missing_text": {"mrr": 0.341660, "mr": 1404.616},
        },
    },
    0.2: {
        "hard_mask": {
            "overall": {"mrr": 0.362198, "mr": 1754.392},
            "head_or_tail_missing_text": {"mrr": 0.345226, "mr": 2079.415},
        },
        "soft_missing_text": {
            "overall": {"mrr": 0.370806, "mr": 1332.314},
            "head_or_tail_missing_text": {"mrr": 0.359703, "mr": 1344.492},
        },
    },
    0.3: {
        "hard_mask": {
            "overall": {"mrr": 0.358271, "mr": 1843.982},
            "head_or_tail_missing_text": {"mrr": 0.343681, "mr": 2080.800},
        },
        "soft_missing_text": {
            "overall": {"mrr": 0.370738, "mr": 1346.483},
            "head_or_tail_missing_text": {"mrr": 0.360706, "mr": 1340.863},
        },
    },
    0.5: {
        "hard_mask": {
            "overall": {"mrr": 0.350220, "mr": 2020.311},
            "head_or_tail_missing_text": {"mrr": 0.342618, "mr": 2170.395},
        },
        "soft_missing_text": {
            "overall": {"mrr": 0.370478, "mr": 1363.686},
            "head_or_tail_missing_text": {"mrr": 0.365869, "mr": 1340.863},
        },
    },
}


SETTINGS = [
    {
        "name": "hard_mask",
        "label": "Hard Mask",
        "extra_args": ["--use-missing-mask"],
        "checkpoint_template": "./checkpoint/rotate_inject_hardmask_r{rate_tag}_seed{seed}.ckpt",
    },
    {
        "name": "soft_missing_text",
        "label": "Soft Missing-Text Token",
        "extra_args": ["--use-soft-missing-text"],
        "checkpoint_template": "./checkpoint/rotate_inject_softtext_r{rate_tag}_seed{seed}.ckpt",
    },
]

SUMMARY_SPLITS = [
    ("overall", "Overall"),
    ("head_or_tail_missing_text", "Head/Tail Missing Text"),
]

METRICS = [
    ("mrr", "MRR"),
    ("mr", "MR"),
    ("hit10", "Hit@10"),
    ("hit3", "Hit@3"),
    ("hit1", "Hit@1"),
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run 3-seed RotatE artificial text-missing-rate sweeps for hard mask vs soft missing-text token."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--seeds", type=int, nargs="+", default=[1, 2])
    parser.add_argument("--rates", type=float, nargs="+", default=[0.1, 0.3, 0.5])
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--train-times", type=int, default=None)
    parser.add_argument("--skip-precomputed-seed0", action="store_true")
    return parser.parse_args()


def rate_to_tag(rate):
    return str(int(round(rate * 100)))


def format_mean_std(values):
    mean_value = statistics.mean(values)
    std_value = statistics.stdev(values) if len(values) > 1 else 0.0
    return f"{mean_value:.6f} +/- {std_value:.6f}"


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    if split_name not in subset_metrics:
        raise KeyError(f"Missing subset metrics for '{split_name}'")
    return subset_metrics[split_name]


def build_precomputed_seed0_results(dataset, rates, use_precomputed_seed0):
    if not use_precomputed_seed0 or dataset != "MKG-Y":
        return []

    results = []
    for rate in rates:
        rate_key = round(rate, 1)
        if rate_key not in PRECOMPUTED_SEED0_MKGY:
            continue
        for setting in SETTINGS:
            precomputed = PRECOMPUTED_SEED0_MKGY[rate_key][setting["name"]]
            results.append(
                {
                    "dataset": dataset,
                    "seed": 0,
                    "inject_text_missing_rate": rate,
                    "setting_name": setting["name"],
                    "setting_label": f"{setting['label']} (seed0 cached)",
                    "overall_metrics": precomputed["overall"],
                    "subset_metrics": {
                        "head_or_tail_missing_text": precomputed["head_or_tail_missing_text"],
                    },
                    "is_precomputed_seed0": True,
                }
            )
    return results


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: ") :])
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def print_per_run_summary(results):
    print("\nPer-run results:")
    print("| Injected Missing Rate | Setting | Seed | Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---:|---|---:|---|---:|---:|---:|---:|---:|")
    for result in results:
        if result.get("is_precomputed_seed0"):
            continue
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            print(
                f"| {result['inject_text_missing_rate']:.0%} | {result['setting_label']} | {result['seed']} | {split_label} | "
                f"{metrics['mrr']:.6f} | {metrics['mr']:.6f} | {metrics['hit10']:.6f} | {metrics['hit3']:.6f} | {metrics['hit1']:.6f} |"
            )


def print_precomputed_seed0_summary(results):
    cached_results = [result for result in results if result.get("is_precomputed_seed0")]
    if not cached_results:
        return
    print("\nCached seed=0 summary merged into final MRR/MR tables:")
    print("| Injected Missing Rate | Setting | Split | MRR | MR |")
    print("|---:|---|---|---:|---:|")
    for result in cached_results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            print(
                f"| {result['inject_text_missing_rate']:.0%} | {result['setting_label']} | {split_label} | "
                f"{metrics['mrr']:.6f} | {metrics['mr']:.6f} |"
            )


def print_paper_tables(results):
    print("\nPaper-ready tables (seed 0/1/2 merged, MRR/MR mean +/- std):")
    for split_name, split_label in SUMMARY_SPLITS:
        print(f"\n[{split_label}]")
        print("| Injected Missing Rate | Hard Mask MRR | Hard Mask MR | Soft Token MRR | Soft Token MR |")
        print("|---:|---:|---:|---:|---:|")
        for rate in sorted({result["inject_text_missing_rate"] for result in results}):
            by_setting = {
                setting["name"]: [
                    result
                    for result in results
                    if result["inject_text_missing_rate"] == rate and result["setting_name"] == setting["name"]
                ]
                for setting in SETTINGS
            }
            hard_metrics_list = [extract_split_metrics(result, split_name) for result in by_setting["hard_mask"]]
            soft_metrics_list = [extract_split_metrics(result, split_name) for result in by_setting["soft_missing_text"]]
            hard_mrr = format_mean_std([metrics["mrr"] for metrics in hard_metrics_list])
            hard_mr = format_mean_std([metrics["mr"] for metrics in hard_metrics_list])
            soft_mrr = format_mean_std([metrics["mrr"] for metrics in soft_metrics_list])
            soft_mr = format_mean_std([metrics["mr"] for metrics in soft_metrics_list])
            print(
                f"| {rate:.0%} | {hard_mrr} | {hard_mr} | {soft_mrr} | {soft_mr} |"
            )


def main():
    args = parse_args()
    results = build_precomputed_seed0_results(
        dataset=args.dataset,
        rates=args.rates,
        use_precomputed_seed0=not args.skip_precomputed_seed0,
    )

    for rate in args.rates:
        for setting in SETTINGS:
            for seed in args.seeds:
                command = [
                    args.python_exe,
                    "train_dhns_rotate.py",
                    "--dataset",
                    args.dataset,
                    "--seed",
                    str(seed),
                    "--inject-text-missing-rate",
                    str(rate),
                    "--subset-eval",
                    "--checkpoint-path",
                    setting["checkpoint_template"].format(rate_tag=rate_to_tag(rate), seed=seed),
                ]
                command.extend(setting["extra_args"])
                if args.train_times is not None:
                    command.extend(["--train-times", str(args.train_times)])

                label = f"{setting['label']} | injected_text_missing={rate:.0%} | seed={seed}"
                result_payload = run_command(label, command)
                result_payload["setting_name"] = setting["name"]
                result_payload["setting_label"] = setting["label"]
                results.append(result_payload)

    print_per_run_summary(results)
    print_precomputed_seed0_summary(results)
    print_paper_tables(results)


if __name__ == "__main__":
    main()
