import argparse
import ctypes
import json
import os
import random

import mmkgc
import numpy as np
import torch

from mmkgc.config import Trainer_dhns, Tester_dhns
from mmkgc.module.model import AdvMixDistMult
from mmkgc.module.loss import SigmoidLoss
from mmkgc.module.strategy import NegativeSampling_complex
from mmkgc.data import TrainDataLoader_complex, TestDataLoader_complex
from mmkgc.adv.mmmodules_distmult import DiffHEG


def parse_args():
    parser = argparse.ArgumentParser(description="Train and evaluate DHNS on a selected MMKG dataset.")
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--use-missing-mask", action="store_true")
    parser.add_argument("--subset-eval", action="store_true")
    parser.add_argument("--debug-masking", action="store_true")
    parser.add_argument("--debug-mask-batches", type=int, default=3)
    parser.add_argument("--checkpoint-path", type=str, default="./checkpoint/distmult.ckpt")
    parser.add_argument("--train-times", type=int, default=400)
    parser.add_argument("--batch-size", type=int, default=2000)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--neg-ent", type=int, default=64)
    parser.add_argument("--alpha", type=float, default=0.002)
    parser.add_argument("--lrg", type=float, default=0.002)
    parser.add_argument("--mu", type=float, default=0.01)
    parser.add_argument("--g-epoch", type=int, default=10)
    parser.add_argument("--no-gpu", action="store_true")
    return parser.parse_args()


def set_seed(seed):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    if torch.backends.cudnn.is_available():
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    try:
        ctypes.cdll.msvcrt.srand(seed)
    except Exception:
        pass


def summarize_missingness(img_emb, text_emb):
    num_entities = text_emb.shape[0]
    if img_emb.shape[0] != num_entities:
        raise ValueError("Image/text embedding row counts do not match.")

    has_text = text_emb.float().norm(dim=1).ne(0)
    has_image = img_emb.float().norm(dim=1).ne(0)
    missing_text_count = int((~has_text).sum().item())
    missing_image_count = int((~has_image).sum().item())

    print("Embedding missingness summary:")
    print(f"  num_entities: {num_entities}")
    print(f"  missing_text_count: {missing_text_count} ({missing_text_count / num_entities:.4%})")
    print(f"  missing_image_count: {missing_image_count} ({missing_image_count / num_entities:.4%})")

    return has_text, has_image


def print_overall_metrics(metrics):
    print("Overall link prediction metrics:")
    print(f"  MRR: {metrics['mrr']:.6f}")
    print(f"  MR: {metrics['mr']:.6f}")
    print(f"  hit@10: {metrics['hit10']:.6f}")
    print(f"  hit@3: {metrics['hit3']:.6f}")
    print(f"  hit@1: {metrics['hit1']:.6f}")


def print_subset_metrics(subset_metrics):
    if subset_metrics is None:
        return
    print("Text-availability subset metrics:")
    for group_name, metrics in subset_metrics.items():
        print(
            "  %s | query_count=%d | triple_count=%d | MRR=%.6f | MR=%.6f | hit@10=%.6f | hit@3=%.6f | hit@1=%.6f"
            % (
                group_name,
                metrics["count"],
                metrics["triple_count"],
                metrics["mrr"],
                metrics["mr"],
                metrics["hit10"],
                metrics["hit3"],
                metrics["hit1"],
            )
        )


def print_subset_sanity(sanity):
    if sanity is None:
        return
    print("Subset evaluation sanity check:")
    print(f"  count_meaning: {sanity['count_meaning']}")
    overall = sanity["overall_query_metrics_same_loop"]
    print(
        "  same_loop_overall | query_count=%d | triple_count=%d | MRR=%.6f | MR=%.6f | hit@10=%.6f | hit@3=%.6f | hit@1=%.6f"
        % (
            overall["count"],
            overall["triple_count"],
            overall["mrr"],
            overall["mr"],
            overall["hit10"],
            overall["hit3"],
            overall["hit1"],
        )
    )
    partition = sanity["partition_recombined_metrics"]
    print(
        "  partition_recombined(head_or_tail_missing + head_and_tail_have_text) | query_count=%d | triple_count=%d | MRR=%.6f | MR=%.6f | hit@10=%.6f | hit@3=%.6f | hit@1=%.6f"
        % (
            partition["count"],
            partition["triple_count"],
            partition["mrr"],
            partition["mr"],
            partition["hit10"],
            partition["hit3"],
            partition["hit1"],
        )
    )


def main():
    args = parse_args()
    set_seed(args.seed)

    use_gpu = torch.cuda.is_available() and not args.no_gpu
    benchmark_path = f"./benchmarks/{args.dataset}/"
    visual_path = f"./embeddings/{args.dataset}-visual.pth"
    textual_path = f"./embeddings/{args.dataset}-textual.pth"

    print(f"Experiment config | dataset={args.dataset} | seed={args.seed} | use_missing_mask={args.use_missing_mask}")

    train_dataloader = TrainDataLoader_complex(
        in_path=benchmark_path,
        batch_size=args.batch_size,
        threads=args.threads,
        sampling_mode="cross",
        bern_flag=0,
        filter_flag=1,
        neg_ent=args.neg_ent,
        neg_rel=0,
    )

    test_dataloader = TestDataLoader_complex(benchmark_path, "link")

    img_emb = torch.load(visual_path)
    text_emb = torch.load(textual_path)
    has_text, has_image = summarize_missingness(img_emb, text_emb)

    distmult = AdvMixDistMult(
        ent_tot=train_dataloader.get_ent_tot(),
        rel_tot=train_dataloader.get_rel_tot(),
        dim=1024,
        margin=200.0,
        epsilon=2.0,
        img_emb=img_emb,
        text_emb=text_emb,
        has_text=has_text,
        use_missing_mask=args.use_missing_mask,
    )

    model = NegativeSampling_complex(
        model=distmult,
        loss=SigmoidLoss(adv_temperature=0.5),
        batch_size=train_dataloader.get_batch_size(),
        l3_regul_rate=0.000005,
    )

    adv_generator = DiffHEG(
        embedding_dim=1024,
        T=50,
        dim_r=1024,
        margin=200.0,
        eps=2.0,
    )

    trainer = Trainer_dhns(
        model=model,
        data_loader=train_dataloader,
        train_times=args.train_times,
        alpha=args.alpha,
        use_gpu=use_gpu,
        opt_method="adam",
        generator=adv_generator,
        lrg=args.lrg,
        mu=args.mu,
        g_epoch=args.g_epoch,
        debug_masking=args.debug_masking,
        debug_mask_batches=args.debug_mask_batches,
    )
    trainer.run()

    checkpoint_dir = os.path.dirname(args.checkpoint_path)
    if checkpoint_dir:
        os.makedirs(checkpoint_dir, exist_ok=True)
    distmult.save_checkpoint(args.checkpoint_path)

    distmult.load_checkpoint(args.checkpoint_path)
    tester = Tester_dhns(model=distmult, data_loader=test_dataloader, use_gpu=use_gpu)
    test_results = tester.run_link_prediction(type_constrain=False, subset_eval=args.subset_eval)
    if args.subset_eval:
        overall_metrics, subset_metrics, subset_sanity = test_results
    else:
        overall_metrics = test_results
        subset_metrics = None
        subset_sanity = None

    print_overall_metrics(overall_metrics)
    print_subset_metrics(subset_metrics)
    print_subset_sanity(subset_sanity)

    result_payload = {
        "dataset": args.dataset,
        "seed": args.seed,
        "use_missing_mask": args.use_missing_mask,
        "missing_text_count": int((~has_text).sum().item()),
        "missing_image_count": int((~has_image).sum().item()),
        "overall_metrics": overall_metrics,
        "subset_metrics": subset_metrics,
        "subset_sanity": subset_sanity,
        "checkpoint_path": args.checkpoint_path,
    }
    print("RESULT_JSON: " + json.dumps(result_payload, sort_keys=True))


if __name__ == "__main__":
    main()
