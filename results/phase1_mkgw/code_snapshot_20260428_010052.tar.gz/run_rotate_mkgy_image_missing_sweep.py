import argparse
import csv
import json
import os
import subprocess
import sys


IMAGE_MISSING_RATES = [0.3, 0.5]

SETTINGS = [
    {
        "name": "no_soft",
        "label": "No Soft Missing-Image",
        "extra_args": [],
        "checkpoint_template": "./checkpoint/rotate_mkgy_imginj_{rate_tag}_nosoft_seed{seed}.ckpt",
    },
    {
        "name": "b_full",
        "label": "B-full",
        "extra_args": ["--use-soft-missing-image"],
        "checkpoint_template": "./checkpoint/rotate_mkgy_imginj_{rate_tag}_bfull_seed{seed}.ckpt",
    },
]

SUMMARY_SPLITS = [
    ("overall", "Overall"),
    ("head_or_tail_missing_image", "Head/Tail Missing Image"),
    ("head_and_tail_have_image", "Head/Tail Both Have Image"),
]

METRICS = [
    ("mrr", "MRR"),
    ("mr", "MR"),
    ("hit10", "Hit@10"),
    ("hit3", "Hit@3"),
    ("hit1", "Hit@1"),
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run MKG-Y image-missing injection stress tests for no-soft vs B-full."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--train-times", type=int, default=None)
    parser.add_argument(
        "--output-csv",
        type=str,
        default="./results/rotate_mkgy_image_missing_sweep_seed0.csv",
    )
    return parser.parse_args()


def rate_to_tag(rate):
    return str(int(round(rate * 100)))


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    metrics = subset_metrics.get(split_name)
    if metrics is None:
        raise KeyError(f"Missing subset metrics for '{split_name}'")
    return metrics


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: "):])
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def build_rows(results):
    rows = []
    for result in results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            rows.append(
                {
                    "inject_image_missing_rate": f"{result['inject_image_missing_rate']:.1f}",
                    "setting": result["setting_label"],
                    "split": split_label,
                    "MRR": f"{metrics['mrr']:.6f}",
                    "MR": f"{metrics['mr']:.6f}",
                    "Hit@10": f"{metrics['hit10']:.6f}",
                    "Hit@3": f"{metrics['hit3']:.6f}",
                    "Hit@1": f"{metrics['hit1']:.6f}",
                }
            )
    return rows


def write_csv(rows, output_csv):
    output_dir = os.path.dirname(output_csv)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    with open(output_csv, "w", encoding="utf-8", newline="") as fout:
        writer = csv.DictWriter(
            fout,
            fieldnames=["inject_image_missing_rate", "setting", "split", "MRR", "MR", "Hit@10", "Hit@3", "Hit@1"],
        )
        writer.writeheader()
        writer.writerows(rows)


def print_summary(rows, output_csv):
    print("\nImage-missing stress test summary:")
    print("| Injected Missing Rate | Setting | Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---:|---|---|---:|---:|---:|---:|---:|")
    for row in rows:
        print(
            f"| {float(row['inject_image_missing_rate']):.0%} | {row['setting']} | {row['split']} | "
            f"{row['MRR']} | {row['MR']} | {row['Hit@10']} | {row['Hit@3']} | {row['Hit@1']} |"
        )
    print(f"\nCSV saved to: {output_csv}")


def print_delta_summary(results):
    results_by_key = {
        (result["inject_image_missing_rate"], result["setting_name"]): result
        for result in results
    }
    print("\nDelta table (B-full - No Soft Missing-Image):")
    print("| Injected Missing Rate | Split | Delta MRR | Delta MR | Delta Hit@10 | Delta Hit@3 | Delta Hit@1 |")
    print("|---:|---|---:|---:|---:|---:|---:|")
    for rate in IMAGE_MISSING_RATES:
        no_soft = results_by_key[(rate, "no_soft")]
        b_full = results_by_key[(rate, "b_full")]
        for split_name, split_label in SUMMARY_SPLITS:
            no_soft_metrics = extract_split_metrics(no_soft, split_name)
            b_full_metrics = extract_split_metrics(b_full, split_name)
            deltas = {
                metric_key: b_full_metrics[metric_key] - no_soft_metrics[metric_key]
                for metric_key, _ in METRICS
            }
            print(
                f"| {rate:.0%} | {split_label} | "
                f"{deltas['mrr']:+.6f} | {deltas['mr']:+.6f} | {deltas['hit10']:+.6f} | "
                f"{deltas['hit3']:+.6f} | {deltas['hit1']:+.6f} |"
            )


def main():
    args = parse_args()
    results = []

    for rate in IMAGE_MISSING_RATES:
        rate_tag = rate_to_tag(rate)
        for setting in SETTINGS:
            checkpoint_path = setting["checkpoint_template"].format(rate_tag=rate_tag, seed=args.seed)
            command = [
                args.python_exe,
                "train_dhns_rotate.py",
                "--dataset",
                args.dataset,
                "--seed",
                str(args.seed),
                "--inject-image-missing-rate",
                str(rate),
                "--subset-eval",
                "--checkpoint-path",
                checkpoint_path,
            ]
            command.extend(setting["extra_args"])
            if args.train_times is not None:
                command.extend(["--train-times", str(args.train_times)])

            result_payload = run_command(
                f"{setting['label']} | dataset={args.dataset} | inject_image_missing={rate:.0%} | seed={args.seed}",
                command,
            )
            result_payload["setting_name"] = setting["name"]
            result_payload["setting_label"] = setting["label"]
            results.append(result_payload)

    rows = build_rows(results)
    write_csv(rows, args.output_csv)
    print_summary(rows, args.output_csv)
    print_delta_summary(results)


if __name__ == "__main__":
    main()
