import argparse
import json
import os
import statistics
import subprocess
import sys


SETTINGS = [
    {
        "name": "hard_mask",
        "label": "RotatE hard mask",
        "extra_args": ["--use-missing-mask"],
        "checkpoint_template": "./checkpoint/rotate_mask_seed{seed}.ckpt",
    },
    {
        "name": "soft_missing_text",
        "label": "RotatE soft missing-text token",
        "extra_args": ["--use-soft-missing-text"],
        "checkpoint_template": "./checkpoint/rotate_softmissing_seed{seed}.ckpt",
    },
]

SUMMARY_SPLITS = [
    ("overall", "Overall"),
    ("head_or_tail_missing_text", "Head/Tail Missing Text"),
    ("head_and_tail_have_text", "Head/Tail Both Have Text"),
]

METRICS = [
    ("mrr", "MRR"),
    ("mr", "MR"),
    ("hit10", "Hit@10"),
    ("hit3", "Hit@3"),
    ("hit1", "Hit@1"),
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run 3-seed RotatE comparisons for hard missing-mask vs soft missing-text token and summarize mean +/- std."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--train-times", type=int, default=None)
    return parser.parse_args()


def format_mean_std(values):
    mean_value = statistics.mean(values)
    std_value = statistics.stdev(values) if len(values) > 1 else 0.0
    return f"{mean_value:.6f} +/- {std_value:.6f}"


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    if split_name not in subset_metrics:
        raise KeyError(f"Missing subset metrics for '{split_name}'")
    return subset_metrics[split_name]


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: ") :])
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def print_per_run_summary(all_results):
    print("\nPer-run results:")
    header = "| Setting | Seed | Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |"
    separator = "|---|---:|---|---:|---:|---:|---:|---:|"
    print(header)
    print(separator)
    for result in all_results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            print(
                f"| {result['setting_label']} | {result['seed']} | {split_label} | "
                f"{metrics['mrr']:.6f} | {metrics['mr']:.6f} | {metrics['hit10']:.6f} | "
                f"{metrics['hit3']:.6f} | {metrics['hit1']:.6f} |"
            )


def print_aggregate_tables(all_results):
    print("\nPaper-ready summary tables (mean +/- std across seeds):")
    for split_name, split_label in SUMMARY_SPLITS:
        print(f"\n[{split_label}]")
        print("| Setting | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
        print("|---|---:|---:|---:|---:|---:|")
        for setting in SETTINGS:
            setting_results = [result for result in all_results if result["setting_name"] == setting["name"]]
            split_metrics = [extract_split_metrics(result, split_name) for result in setting_results]
            row_values = []
            for metric_key, _ in METRICS:
                row_values.append(format_mean_std([metrics[metric_key] for metrics in split_metrics]))
            print(
                f"| {setting['label']} | {row_values[0]} | {row_values[1]} | {row_values[2]} | {row_values[3]} | {row_values[4]} |"
            )


def main():
    args = parse_args()
    all_results = []

    for setting in SETTINGS:
        for seed in args.seeds:
            command = [
                args.python_exe,
                "train_dhns_rotate.py",
                "--dataset",
                args.dataset,
                "--seed",
                str(seed),
                "--subset-eval",
                "--checkpoint-path",
                setting["checkpoint_template"].format(seed=seed),
            ]
            command.extend(setting["extra_args"])
            if args.train_times is not None:
                command.extend(["--train-times", str(args.train_times)])

            label = f"{setting['label']} | seed={seed}"
            result_payload = run_command(label, command)
            result_payload["setting_name"] = setting["name"]
            result_payload["setting_label"] = setting["label"]
            all_results.append(result_payload)

    print_per_run_summary(all_results)
    print_aggregate_tables(all_results)


if __name__ == "__main__":
    main()
