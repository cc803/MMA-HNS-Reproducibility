import argparse
import csv
import json
import os
import subprocess
import sys


SETTINGS = [
    {
        "name": "weaker",
        "label": "Weaker Consistency",
        "extra_args": [
            "--use-soft-missing-text",
            "--use-missing-text-consistency",
            "--consistency-prob",
            "0.05",
            "--consistency-lambda",
            "0.02",
        ],
        "checkpoint_template": "./checkpoint/rotate_mkgy_consistency_weaker_seed{seed}.ckpt",
    },
    {
        "name": "stronger",
        "label": "Stronger Consistency",
        "extra_args": [
            "--use-soft-missing-text",
            "--use-missing-text-consistency",
            "--consistency-prob",
            "0.2",
            "--consistency-lambda",
            "0.1",
        ],
        "checkpoint_template": "./checkpoint/rotate_mkgy_consistency_stronger_seed{seed}.ckpt",
    },
]

SUMMARY_SPLITS = [
    ("overall", "Overall"),
    ("head_or_tail_missing_text", "Head/Tail Missing Text"),
    ("head_and_tail_have_text", "Head/Tail Both Have Text"),
]

METRICS = [
    ("mrr", "MRR"),
    ("mr", "MR"),
    ("hit10", "Hit@10"),
    ("hit3", "Hit@3"),
    ("hit1", "Hit@1"),
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run MKG-Y minimal consistency tuning for the A+B text baseline."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--inject-text-missing-rate", type=float, default=0.0)
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--train-times", type=int, default=None)
    parser.add_argument(
        "--output-csv",
        type=str,
        default="./results/rotate_mkgy_consistency_tuning_seed0.csv",
    )
    return parser.parse_args()


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    metrics = subset_metrics.get(split_name)
    if metrics is None:
        raise KeyError(f"Missing subset metrics for '{split_name}'")
    return metrics


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: "):])
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def build_rows(results):
    rows = []
    for result in results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            rows.append(
                {
                    "setting": result["setting_label"],
                    "inject_text_missing_rate": f"{result['inject_text_missing_rate']:.1f}",
                    "split": split_label,
                    "MRR": f"{metrics['mrr']:.6f}",
                    "MR": f"{metrics['mr']:.6f}",
                    "Hit@10": f"{metrics['hit10']:.6f}",
                    "Hit@3": f"{metrics['hit3']:.6f}",
                    "Hit@1": f"{metrics['hit1']:.6f}",
                }
            )
    return rows


def write_csv(rows, output_csv):
    output_dir = os.path.dirname(output_csv)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    with open(output_csv, "w", encoding="utf-8", newline="") as fout:
        writer = csv.DictWriter(
            fout,
            fieldnames=["setting", "inject_text_missing_rate", "split", "MRR", "MR", "Hit@10", "Hit@3", "Hit@1"],
        )
        writer.writeheader()
        writer.writerows(rows)


def print_summary(rows, output_csv):
    print("\nConsistency tuning summary:")
    print("| Setting | Injected Missing Rate | Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---|---:|---|---:|---:|---:|---:|---:|")
    for row in rows:
        print(
            f"| {row['setting']} | {float(row['inject_text_missing_rate']):.0%} | {row['split']} | "
            f"{row['MRR']} | {row['MR']} | {row['Hit@10']} | {row['Hit@3']} | {row['Hit@1']} |"
        )
    print(f"\nCSV saved to: {output_csv}")


def print_delta_summary(results):
    results_by_name = {result["setting_name"]: result for result in results}
    weaker = results_by_name["weaker"]
    stronger = results_by_name["stronger"]
    print("\nDelta table (Stronger - Weaker):")
    print("| Split | Delta MRR | Delta MR | Delta Hit@10 | Delta Hit@3 | Delta Hit@1 |")
    print("|---|---:|---:|---:|---:|---:|")
    for split_name, split_label in SUMMARY_SPLITS:
        weaker_metrics = extract_split_metrics(weaker, split_name)
        stronger_metrics = extract_split_metrics(stronger, split_name)
        deltas = {
            metric_key: stronger_metrics[metric_key] - weaker_metrics[metric_key]
            for metric_key, _ in METRICS
        }
        print(
            f"| {split_label} | {deltas['mrr']:+.6f} | {deltas['mr']:+.6f} | "
            f"{deltas['hit10']:+.6f} | {deltas['hit3']:+.6f} | {deltas['hit1']:+.6f} |"
        )


def main():
    args = parse_args()
    results = []

    for setting in SETTINGS:
        checkpoint_path = setting["checkpoint_template"].format(seed=args.seed)
        command = [
            args.python_exe,
            "train_dhns_rotate.py",
            "--dataset",
            args.dataset,
            "--seed",
            str(args.seed),
            "--inject-text-missing-rate",
            str(args.inject_text_missing_rate),
            "--subset-eval",
            "--checkpoint-path",
            checkpoint_path,
        ]
        command.extend(setting["extra_args"])
        if args.train_times is not None:
            command.extend(["--train-times", str(args.train_times)])

        result_payload = run_command(
            f"{setting['label']} | dataset={args.dataset} | inject_text_missing={args.inject_text_missing_rate:.0%} | seed={args.seed}",
            command,
        )
        result_payload["setting_name"] = setting["name"]
        result_payload["setting_label"] = setting["label"]
        results.append(result_payload)

    rows = build_rows(results)
    write_csv(rows, args.output_csv)
    print_summary(rows, args.output_csv)
    print_delta_summary(results)


if __name__ == "__main__":
    main()
