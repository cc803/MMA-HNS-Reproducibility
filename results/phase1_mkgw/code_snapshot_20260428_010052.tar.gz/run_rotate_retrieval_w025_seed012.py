import argparse
import csv
import json
import math
import os
import statistics
import subprocess
import sys


SUMMARY_SPLITS = [
    ("overall", "Overall"),
    ("head_or_tail_missing_text", "Head/Tail Missing Text"),
    ("head_and_tail_have_text", "Head/Tail Both Have Text"),
]

METRICS = [
    ("mrr", "MRR"),
    ("mr", "MR"),
    ("hit10", "Hit@10"),
    ("hit3", "Hit@3"),
    ("hit1", "Hit@1"),
]

EMBEDDED_SEED0_RESULT = {
    "model": "AdvMixRotatE",
    "dataset": "MKG-Y",
    "seed": 0,
    "checkpoint_path": "./checkpoint/rotate_retrieval_w025.ckpt",
    "use_retrieval_missing_text": True,
    "retrieval_topk": 5,
    "retrieval_pool_size": 512,
    "retrieval_source": "entity_embedding_knn",
    "retrieval_mix_weight": 0.25,
    "overall_metrics": {
        "mrr": 0.3727347254753113,
        "mr": 1280.5010986328125,
        "hit10": 0.45043182373046875,
        "hit3": 0.4008636772632599,
        "hit1": 0.3248216509819031,
    },
    "subset_metrics": {
        "head_or_tail_missing_text": {
            "count": 1934,
            "count_type": "query",
            "triple_count": 967,
            "mrr": 0.3355504048632497,
            "mr": 1326.543950361944,
            "hit10": 0.40692864529472594,
            "hit3": 0.359358841778697,
            "hit1": 0.29317476732161324,
        },
        "head_and_tail_have_text": {
            "count": 3392,
            "count_type": "query",
            "triple_count": 1696,
            "mrr": 0.3939369334613675,
            "mr": 1254.2491155660377,
            "hit10": 0.47523584905660377,
            "hit3": 0.42452830188679247,
            "hit1": 0.3428655660377358,
        },
    },
}


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run MKG-Y retrieval missing-text w=0.25 for 3 seeds. Seed 0 uses the embedded completed result by default."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--seed0-checkpoint", type=str, default="./checkpoint/rotate_retrieval_w025.ckpt")
    parser.add_argument("--seed0-json-path", type=str, default=None)
    parser.add_argument("--retest-seed0", action="store_true")
    parser.add_argument("--seeds", type=int, nargs="+", default=[1, 2])
    parser.add_argument("--checkpoint-template", type=str, default="./checkpoint/rotate_retrieval_w025_seed{seed}.ckpt")
    parser.add_argument("--retrieval-pool-size", type=int, default=512)
    parser.add_argument("--retrieval-mix-weight", type=float, default=0.25)
    parser.add_argument("--output-dir", type=str, default="./results")
    parser.add_argument("--train-times", type=int, default=None)
    return parser.parse_args()


def load_json_file(path):
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file, parse_constant=lambda _value: float("nan"))


def write_json(path, payload):
    with open(path, "w", encoding="utf-8") as file:
        json.dump(payload, file, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=True)


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    if split_name not in subset_metrics:
        raise KeyError(f"Missing subset metrics for '{split_name}' in seed {result_payload.get('seed')}")
    return subset_metrics[split_name]


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: "):], parse_constant=lambda _value: float("nan"))
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def build_base_args(args):
    command = [
        "train_dhns_rotate.py",
        "--dataset",
        args.dataset,
        "--use-retrieval-missing-text",
        "--retrieval-pool-size",
        str(args.retrieval_pool_size),
        "--retrieval-mix-weight",
        str(args.retrieval_mix_weight),
        "--subset-eval",
    ]
    if args.train_times is not None:
        command.extend(["--train-times", str(args.train_times)])
    return command


def get_seed0_result(args):
    if args.seed0_json_path:
        print(f"Loading seed0 RESULT_JSON from: {args.seed0_json_path}", flush=True)
        return load_json_file(args.seed0_json_path)

    if not args.retest_seed0:
        print("Using embedded seed0 RESULT_JSON for retrieval w=0.25.", flush=True)
        return json.loads(json.dumps(EMBEDDED_SEED0_RESULT))

    command = [
        args.python_exe,
        *build_base_args(args),
        "--seed",
        "0",
        "--test",
        "--checkpoint-path",
        args.seed0_checkpoint,
    ]
    return run_command("Retrieval missing-text w=0.25 | seed=0 | test-only", command)


def get_train_result(args, seed):
    checkpoint_path = args.checkpoint_template.format(seed=seed)
    command = [
        args.python_exe,
        *build_base_args(args),
        "--seed",
        str(seed),
        "--checkpoint-path",
        checkpoint_path,
    ]
    return run_command(f"Retrieval missing-text w=0.25 | seed={seed}", command)


def safe_float(value):
    number = float(value)
    return number if not math.isnan(number) else float("nan")


def mean_std(values):
    clean_values = [safe_float(value) for value in values]
    mean_value = statistics.mean(clean_values)
    std_value = statistics.stdev(clean_values) if len(clean_values) > 1 else 0.0
    return mean_value, std_value


def write_per_run_csv(path, results):
    with open(path, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["seed", "split", "mrr", "mr", "hit10", "hit3", "hit1"])
        for result in results:
            for split_name, split_label in SUMMARY_SPLITS:
                metrics = extract_split_metrics(result, split_name)
                writer.writerow([
                    result["seed"],
                    split_label,
                    metrics["mrr"],
                    metrics["mr"],
                    metrics["hit10"],
                    metrics["hit3"],
                    metrics["hit1"],
                ])


def write_summary_csv(path, results):
    with open(path, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["split", "metric", "mean", "std"])
        for split_name, split_label in SUMMARY_SPLITS:
            split_metrics = [extract_split_metrics(result, split_name) for result in results]
            for metric_key, metric_label in METRICS:
                mean_value, std_value = mean_std([metrics[metric_key] for metrics in split_metrics])
                writer.writerow([split_label, metric_label, mean_value, std_value])


def print_summary(results):
    print("\nPer-seed summary:")
    print("| Seed | Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---:|---|---:|---:|---:|---:|---:|")
    for result in results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            print(
                f"| {result['seed']} | {split_label} | {metrics['mrr']:.6f} | {metrics['mr']:.6f} | "
                f"{metrics['hit10']:.6f} | {metrics['hit3']:.6f} | {metrics['hit1']:.6f} |"
            )

    print("\n3-seed aggregate (mean +/- std):")
    print("| Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---|---:|---:|---:|---:|---:|")
    for split_name, split_label in SUMMARY_SPLITS:
        split_metrics = [extract_split_metrics(result, split_name) for result in results]
        formatted = []
        for metric_key, _metric_label in METRICS:
            mean_value, std_value = mean_std([metrics[metric_key] for metrics in split_metrics])
            formatted.append(f"{mean_value:.6f} +/- {std_value:.6f}")
        print(f"| {split_label} | {formatted[0]} | {formatted[1]} | {formatted[2]} | {formatted[3]} | {formatted[4]} |")


def main():
    args = parse_args()
    if args.retrieval_mix_weight != 0.25:
        print(f"Warning: this runner is named for w=0.25, but --retrieval-mix-weight={args.retrieval_mix_weight}.", flush=True)

    os.makedirs(args.output_dir, exist_ok=True)

    all_results = [get_seed0_result(args)]
    if int(all_results[0].get("seed", -1)) != 0:
        raise ValueError("Seed-0 result payload must have seed=0.")
    write_json(os.path.join(args.output_dir, "rotate_retrieval_w025_seed0_result.json"), all_results[0])

    for seed in args.seeds:
        result = get_train_result(args, seed)
        write_json(os.path.join(args.output_dir, f"rotate_retrieval_w025_seed{seed}_result.json"), result)
        all_results.append(result)

    all_results.sort(key=lambda item: int(item["seed"]))
    per_run_csv_path = os.path.join(args.output_dir, "rotate_retrieval_w025_seed012_runs.csv")
    summary_csv_path = os.path.join(args.output_dir, "rotate_retrieval_w025_seed012_summary.csv")
    write_per_run_csv(per_run_csv_path, all_results)
    write_summary_csv(summary_csv_path, all_results)
    print_summary(all_results)

    print("\nSaved files:")
    for result in all_results:
        seed = result["seed"]
        result_path = os.path.abspath(os.path.join(args.output_dir, f"rotate_retrieval_w025_seed{seed}_result.json"))
        print(f"  seed{seed}_result_json: {result_path}")
    print(f"  per_run_csv: {os.path.abspath(per_run_csv_path)}")
    print(f"  summary_csv: {os.path.abspath(summary_csv_path)}")


if __name__ == "__main__":
    main()
