import argparse
import csv
import json
import math
import os
import re
import statistics
from collections import defaultdict


DEFAULT_RESULTS_DIR = os.path.join(".", "results", "phase1_mkgy")

METHOD_ORDER = [
    "rotate_baseline",
    "hard_mask",
    "soft_token",
    "soft_token_retrieval",
    "soft_token_retrieval_guarded_hpsac",
]

SPLIT_ORDER = [
    ("overall", "Overall"),
    ("head_or_tail_missing_text", "Head/Tail Missing Text"),
    ("head_and_tail_have_text", "Head/Tail Both Have Text"),
    ("head_or_tail_injected_missing_text", "Head/Tail Injected Missing Text"),
]

METRIC_COLUMNS = [
    ("mrr", "MRR", "MRR"),
    ("mr", "MR", "MR"),
    ("hit10", "Hit@10", "H10"),
    ("hit3", "Hit@3", "H3"),
    ("hit1", "Hit@1", "H1"),
]

LOG_NAME_RE = re.compile(r"^(?P<method>.+)_seed(?P<seed>\d+)\.log$")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Summarize phase1 MKG-Y logs by extracting RESULT_JSON payloads."
    )
    parser.add_argument("--results-dir", type=str, default=DEFAULT_RESULTS_DIR)
    return parser.parse_args()


def load_result_json_from_log(log_path):
    result_payload = None
    with open(log_path, "r", encoding="utf-8", errors="replace") as fin:
        for line in fin:
            if line.startswith("RESULT_JSON: "):
                result_payload = json.loads(
                    line[len("RESULT_JSON: "):],
                    parse_constant=lambda _value: float("nan"),
                )
    return result_payload


def method_seed_from_log_path(log_path):
    name = os.path.basename(log_path)
    match = LOG_NAME_RE.match(name)
    if match is None:
        raise ValueError(
            "Log filename must match '<method>_seed<S>.log': %s" % log_path
        )
    return match.group("method"), int(match.group("seed"))


def metric_source(payload):
    if "test_overall_metrics" in payload:
        return payload.get("test_overall_metrics"), payload.get("test_subset_metrics") or {}
    return payload.get("overall_metrics"), payload.get("subset_metrics") or {}


def checkpoint_for_payload(payload):
    if payload.get("checkpoint_path"):
        return payload["checkpoint_path"]
    checkpoint_a = payload.get("checkpoint_a")
    checkpoint_b = payload.get("checkpoint_b")
    if checkpoint_a or checkpoint_b:
        return "checkpoint_a=%s; checkpoint_b=%s" % (checkpoint_a, checkpoint_b)
    return ""


def split_metrics(payload):
    overall_metrics, subset_metrics = metric_source(payload)
    rows = []
    if overall_metrics is not None:
        rows.append(("overall", "Overall", overall_metrics))
    for split_key, split_label in SPLIT_ORDER[1:]:
        if split_key in subset_metrics:
            rows.append((split_key, split_label, subset_metrics[split_key]))
    return rows


def to_float(value):
    if value is None:
        return float("nan")
    return float(value)


def csv_number(value):
    value = to_float(value)
    if math.isnan(value):
        return "nan"
    return repr(value)


def mean_std(values):
    clean = [to_float(value) for value in values]
    if not clean:
        return float("nan"), float("nan")
    mean_value = statistics.mean(clean)
    std_value = statistics.stdev(clean) if len(clean) > 1 else 0.0
    return mean_value, std_value


def method_sort_key(method):
    try:
        return METHOD_ORDER.index(method)
    except ValueError:
        return len(METHOD_ORDER)


def split_sort_key(split_label):
    labels = [label for _key, label in SPLIT_ORDER]
    try:
        return labels.index(split_label)
    except ValueError:
        return len(labels)


def discover_logs(results_dir):
    log_paths = []
    for root, _dirs, files in os.walk(results_dir):
        for name in files:
            if name.endswith(".log"):
                log_paths.append(os.path.join(root, name))
    return sorted(log_paths)


def build_records(results_dir):
    log_paths = discover_logs(results_dir)
    if not log_paths:
        raise SystemExit("No .log files found under: %s" % results_dir)

    run_rows = []
    raw_results = []
    skipped_logs = []
    for log_path in log_paths:
        method, seed = method_seed_from_log_path(log_path)
        payload = load_result_json_from_log(log_path)
        if payload is None:
            skipped_logs.append(log_path)
            continue

        payload_seed = payload.get("seed")
        if payload_seed is not None and int(payload_seed) != seed:
            print(
                "Warning: payload seed %s differs from filename seed %s in %s"
                % (payload_seed, seed, log_path)
            )

        checkpoint = checkpoint_for_payload(payload)
        for _split_key, split_label, metrics in split_metrics(payload):
            run_rows.append(
                {
                    "method": method,
                    "seed": seed,
                    "split": split_label,
                    "MRR": metrics.get("mrr"),
                    "MR": metrics.get("mr"),
                    "Hit@10": metrics.get("hit10"),
                    "Hit@3": metrics.get("hit3"),
                    "Hit@1": metrics.get("hit1"),
                    "checkpoint": checkpoint,
                    "log_file": os.path.normpath(log_path),
                }
            )

        raw_results.append(
            {
                "method": method,
                "seed": seed,
                "log_file": os.path.normpath(log_path),
                "result_json": payload,
            }
        )

    for log_path in skipped_logs:
        print("Warning: no RESULT_JSON found in %s" % log_path)

    run_rows.sort(key=lambda row: (method_sort_key(row["method"]), row["method"], row["seed"], split_sort_key(row["split"])))
    raw_results.sort(key=lambda row: (method_sort_key(row["method"]), row["method"], row["seed"]))
    return run_rows, raw_results


def write_runs_csv(path, run_rows):
    fieldnames = [
        "method",
        "seed",
        "split",
        "MRR",
        "MR",
        "Hit@10",
        "Hit@3",
        "Hit@1",
        "checkpoint",
        "log_file",
    ]
    with open(path, "w", encoding="utf-8", newline="") as fout:
        writer = csv.DictWriter(fout, fieldnames=fieldnames)
        writer.writeheader()
        for row in run_rows:
            output = dict(row)
            for field in ["MRR", "MR", "Hit@10", "Hit@3", "Hit@1"]:
                output[field] = csv_number(output[field])
            writer.writerow(output)


def write_summary_csv(path, run_rows):
    grouped = defaultdict(list)
    for row in run_rows:
        grouped[(row["method"], row["split"])].append(row)

    fieldnames = [
        "method",
        "split",
        "MRR_mean",
        "MRR_std",
        "MR_mean",
        "MR_std",
        "H10_mean",
        "H10_std",
        "H3_mean",
        "H3_std",
        "H1_mean",
        "H1_std",
    ]
    with open(path, "w", encoding="utf-8", newline="") as fout:
        writer = csv.DictWriter(fout, fieldnames=fieldnames)
        writer.writeheader()
        for method, split in sorted(grouped, key=lambda key: (method_sort_key(key[0]), key[0], split_sort_key(key[1]))):
            rows = grouped[(method, split)]
            output = {"method": method, "split": split}
            for source_field, _runs_field, summary_prefix in METRIC_COLUMNS:
                values = [row[_runs_field] for row in rows]
                mean_value, std_value = mean_std(values)
                output[f"{summary_prefix}_mean"] = csv_number(mean_value)
                output[f"{summary_prefix}_std"] = csv_number(std_value)
            writer.writerow(output)


def write_raw_json(path, raw_results):
    with open(path, "w", encoding="utf-8") as fout:
        json.dump(raw_results, fout, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=True)


def print_nan_report(run_rows):
    nan_rows = []
    for row in run_rows:
        if any(math.isnan(to_float(row[field])) for field in ["MRR", "MR", "Hit@10", "Hit@3", "Hit@1"]):
            nan_rows.append((row["method"], row["seed"], row["split"]))
    if not nan_rows:
        print("NaN split report: none")
        return
    print("NaN split report:")
    for method, seed, split in nan_rows:
        print("  method=%s | seed=%s | split=%s" % (method, seed, split))


def main():
    args = parse_args()
    results_dir = os.path.normpath(args.results_dir)
    run_rows, raw_results = build_records(results_dir)

    os.makedirs(results_dir, exist_ok=True)
    runs_csv = os.path.join(results_dir, "main_runs.csv")
    summary_csv = os.path.join(results_dir, "main_summary.csv")
    raw_json = os.path.join(results_dir, "main_results.json")

    write_runs_csv(runs_csv, run_rows)
    write_summary_csv(summary_csv, run_rows)
    write_raw_json(raw_json, raw_results)

    print("Saved run table: %s" % os.path.abspath(runs_csv))
    print("Saved summary table: %s" % os.path.abspath(summary_csv))
    print("Saved raw RESULT_JSON payloads: %s" % os.path.abspath(raw_json))
    print_nan_report(run_rows)


if __name__ == "__main__":
    main()
