#!/usr/bin/env bash
set -euo pipefail

PYTHON_EXE="${PYTHON_EXE:-python}"

run_step() {
    local label="$1"
    shift

    echo "==> ${label}"
    echo "${PYTHON_EXE} $*"
    "${PYTHON_EXE}" "$@"
    echo "<== Completed: ${label}"
}

run_step "Retrieval missing-text | mix_weight=0.1" \
    train_dhns_rotate.py \
    --dataset MKG-Y \
    --seed 0 \
    --use-retrieval-missing-text \
    --retrieval-pool-size 512 \
    --retrieval-mix-weight 0.1 \
    --subset-eval \
    --checkpoint-path ./checkpoint/rotate_retrieval_w01.ckpt

run_step "Retrieval missing-text | mix_weight=0.25" \
    train_dhns_rotate.py \
    --dataset MKG-Y \
    --seed 0 \
    --use-retrieval-missing-text \
    --retrieval-pool-size 512 \
    --retrieval-mix-weight 0.25 \
    --subset-eval \
    --checkpoint-path ./checkpoint/rotate_retrieval_w025.ckpt

run_step "Retrieval missing-text | mix_weight=0.5" \
    train_dhns_rotate.py \
    --dataset MKG-Y \
    --seed 0 \
    --use-retrieval-missing-text \
    --retrieval-pool-size 512 \
    --retrieval-mix-weight 0.5 \
    --subset-eval \
    --checkpoint-path ./checkpoint/rotate_retrieval_w05.ckpt
