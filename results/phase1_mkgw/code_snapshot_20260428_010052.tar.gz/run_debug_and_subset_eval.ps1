$ErrorActionPreference = "Stop"

param(
    [string]$PythonExe = "python"
)

function Run-Step {
    param(
        [string]$Label,
        [string[]]$Args
    )

    Write-Host "==> $Label" -ForegroundColor Cyan
    Write-Host "$PythonExe $($Args -join ' ')" -ForegroundColor DarkGray
    & $PythonExe @Args
    if ($LASTEXITCODE -ne 0) {
        throw "Step failed: $Label"
    }
    Write-Host "<== Completed: $Label" -ForegroundColor Green
}

Run-Step -Label "Debug masking run 1" -Args @(
    "train_dhns.py",
    "--dataset", "MKG-Y",
    "--seed", "0",
    "--use-missing-mask",
    "--debug-masking",
    "--debug-mask-batches", "3",
    "--checkpoint-path", "./checkpoint/debug_mask.ckpt"
)

Run-Step -Label "Debug masking run 2" -Args @(
    "train_dhns.py",
    "--dataset", "MKG-Y",
    "--seed", "0",
    "--use-missing-mask",
    "--debug-masking",
    "--debug-mask-batches", "3",
    "--checkpoint-path", "./checkpoint/debug_mask.ckpt"
)

Run-Step -Label "Subset evaluation run" -Args @(
    "train_dhns.py",
    "--dataset", "MKG-Y",
    "--seed", "0",
    "--use-missing-mask",
    "--subset-eval",
    "--checkpoint-path", "./checkpoint/distmult_mask_seed0.ckpt"
)
