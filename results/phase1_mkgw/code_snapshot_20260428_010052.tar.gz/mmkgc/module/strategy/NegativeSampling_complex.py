from .Strategy import Strategy

class NegativeSampling_complex(Strategy):

	def __init__(self, model = None, loss = None, batch_size = 256, regul_rate = 0.0, l3_regul_rate = 0.0):
		super(NegativeSampling_complex, self).__init__()
		self.model = model
		self.loss = loss
		self.batch_size = batch_size
		self.regul_rate = regul_rate
		self.l3_regul_rate = l3_regul_rate
		self.last_p_score = None
		self.last_n_score = None

	def _get_positive_score(self, score):
		positive_score = score[:self.batch_size]
		positive_score = positive_score.view(-1, self.batch_size).permute(1, 0)
		return positive_score

	def _get_negative_score(self, score):
		negative_score = score[self.batch_size:]
		negative_score = negative_score.view(-1, self.batch_size).permute(1, 0)
		return negative_score

	def forward(self, data):
		score = self.model(data)
		p_score = self._get_positive_score(score)
		n_score = self._get_negative_score(score)
		if data.get('capture_scores_for_aux', False):
			self.last_p_score = p_score
			self.last_n_score = n_score
		else:
			self.last_p_score = None
			self.last_n_score = None
		sample_weight = data.get('sample_weight')
		loss_res = self.loss(p_score, n_score, sample_weight = sample_weight)
		if self.regul_rate != 0:
			loss_res += self.regul_rate * self.model.regularization(data)
		if self.l3_regul_rate != 0:
			loss_res += self.l3_regul_rate * self.model.l3_regularization()
		return loss_res, p_score

	def consume_last_scores(self):
		p_score = self.last_p_score
		n_score = self.last_n_score
		self.last_p_score = None
		self.last_n_score = None
		return p_score, n_score
