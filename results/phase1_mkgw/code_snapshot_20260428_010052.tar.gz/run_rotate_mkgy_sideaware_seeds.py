import argparse
import csv
import json
import os
import statistics
import subprocess
import sys


EMBEDDED_SEED0_RESULT_JSON = r"""{"active_modalities": ["structural", "visual", "text"], "active_modality_count": 3, "checkpoint_path": "./checkpoint/rotate_sideaware_seed0.ckpt", "consistency_lambda": 0.05, "consistency_prob": 0.1, "dataset": "MKG-Y", "debug_fusion_sanity": false, "debug_joint_scoring_sanity": false, "debug_missing_aware_joint_scoring": false, "debug_missing_aware_joint_scoring_batches": 3, "debug_reliability": false, "debug_reliability_batches": 3, "entity_specific_missing_text_recon_weight": 0.0, "image_injection_info": null, "inject_image_missing_rate": 0.0, "inject_text_missing_rate": 0.0, "injected_image_count": 0, "injected_text_count": 0, "injection_info": null, "learned_missing_text_gate": null, "learned_missing_text_token_scale": null, "missing_image_count": 756, "missing_sample_weight": 1.0, "missing_text_attention_scale": 1.0, "missing_text_count": 2684, "model": "AdvMixRotatE", "overall_metrics": {"hit1": 0.3221930265426636, "hit10": 0.45212167501449585, "hit3": 0.4001126289367676, "mr": 1297.828125, "mrr": 0.3713687062263489}, "prototype_cluster_path": null, "prototype_num_clusters": null, "prototype_unique_cluster_count": null, "pseudo_missing_prob": 0.0, "seed": 0, "subset_metrics": {"head_and_tail_have_image": {"count": 4746, "count_type": "query", "hit1": 0.2867678044669195, "hit10": 0.41761483354403706, "hit3": 0.365149599662874, "mr": 1344.5811209439528, "mrr": 0.336530053130157, "triple_count": 2373}, "head_and_tail_have_text": {"count": 3392, "count_type": "query", "hit1": 0.3419811320754717, "hit10": 0.47847877358490565, "hit3": 0.42452830188679247, "mr": 1246.5200471698113, "mrr": 0.39380394656001233, "triple_count": 1696}, "head_missing_image": {"count": 268, "count_type": "query", "hit1": 0.5746268656716418, "hit10": 0.7164179104477612, "hit3": 0.6567164179104478, "mr": 749.6940298507462, "mrr": 0.6249346579532872, "triple_count": 134}, "head_missing_text": {"count": 1188, "count_type": "query", "hit1": 0.234006734006734, "hit10": 0.3501683501683502, "hit3": 0.29797979797979796, "mr": 1459.5824915824917, "mrr": 0.27722862583875013, "triple_count": 594}, "head_or_tail_both_have_image": {"count": 4746, "count_type": "query", "hit1": 0.2867678044669195, "hit10": 0.41761483354403706, "hit3": 0.365149599662874, "mr": 1344.5811209439528, "mrr": 0.336530053130157, "triple_count": 2373}, "head_or_tail_both_have_text": {"count": 3392, "count_type": "query", "hit1": 0.3419811320754717, "hit10": 0.47847877358490565, "hit3": 0.42452830188679247, "mr": 1246.5200471698113, "mrr": 0.39380394656001233, "triple_count": 1696}, "head_or_tail_injected_missing_text": {"count": 0, "count_type": "query", "hit1": NaN, "hit10": NaN, "hit3": NaN, "mr": NaN, "mrr": NaN, "triple_count": 0}, "head_or_tail_missing_image": {"count": 580, "count_type": "query", "hit1": 0.6120689655172413, "hit10": 0.7344827586206897, "hit3": 0.6862068965517242, "mr": 915.2603448275862, "mrr": 0.6564520189492034, "triple_count": 290}, "head_or_tail_missing_text": {"count": 1934, "count_type": "query", "hit1": 0.2874870734229576, "hit10": 0.405894519131334, "hit3": 0.3572905894519131, "mr": 1387.816442605998, "mrr": 0.3320221387873325, "triple_count": 967}, "tail_missing_image": {"count": 360, "count_type": "query", "hit1": 0.6388888888888888, "hit10": 0.7583333333333333, "hit3": 0.7083333333333334, "mr": 1005.4333333333333, "mrr": 0.6809697911178985, "triple_count": 180}, "tail_missing_text": {"count": 952, "count_type": "query", "hit1": 0.3560924369747899, "hit10": 0.4789915966386555, "hit3": 0.43067226890756305, "mr": 1188.6334033613446, "mrr": 0.4011942742846345, "triple_count": 476}}, "subset_sanity": {"count_meaning": "query_count counts head/tail prediction queries; triple_count counts original test triples.", "image_partition_recombined_metrics": {"count": 5326, "count_type": "query", "hit1": 0.32219301539616974, "hit10": 0.45212166729252723, "hit3": 0.4001126549004882, "mr": 1297.8282012767556, "mrr": 0.37136947111270435, "triple_count": 2663}, "overall_query_metrics_same_loop": {"count": 5326, "count_type": "query", "hit1": 0.32219301539616974, "hit10": 0.45212166729252723, "hit3": 0.4001126549004882, "mr": 1297.8282012767556, "mrr": 0.37136947111270435, "triple_count": 2663}, "partition_recombined_metrics": {"count": 5326, "count_type": "query", "hit1": 0.32219301539616974, "hit10": 0.45212166729252723, "hit3": 0.4001126549004882, "mr": 1297.8282012767556, "mrr": 0.37136947111270424, "triple_count": 2663}, "text_partition_recombined_metrics": {"count": 5326, "count_type": "query", "hit1": 0.32219301539616974, "hit10": 0.45212166729252723, "hit3": 0.4001126549004882, "mr": 1297.8282012767556, "mrr": 0.37136947111270424, "triple_count": 2663}}, "test_only": false, "text_branch_debug": {"active_modalities": ["structural", "visual", "text"], "active_modality_count": 3, "consistency_lambda": 0.05, "consistency_prob": 0.1, "entity_specific_missing_text_debug_count": 0, "entity_specific_missing_text_recon_weight": 0.0, "generator_text_alignment_debug_printed": false, "last_entity_specific_missing_text_stats": null, "last_missing_text_consistency_stats": null, "last_prototype_missing_text_stats": null, "last_structure_conditioned_missing_text_stats": null, "missing_text_consistency_debug_count": 0, "missing_text_token_head_norm": 0.8681926131248474, "missing_text_token_norm": 0.0, "missing_text_token_scale": 1.0, "missing_text_token_tail_norm": 0.8711223602294922, "prototype_missing_text_debug_count": 0, "prototype_missing_text_num_clusters": null, "pseudo_missing_debug_count": 0, "pseudo_missing_prob": 0.0, "structure_conditioned_missing_text_debug_count": 0, "text_branch_enabled": true, "text_off_debug_printed": false, "use_entity_specific_missing_text": false, "use_missing_text_consistency": false, "use_missing_text_token_scale": false, "use_prototype_missing_text": false, "use_side_aware_missing_text": true, "use_soft_token_text_generator_alignment": false, "use_structure_conditioned_missing_text": false}, "text_mode": "soft_token", "truly_missing_text_count": 2684, "use_entity_specific_missing_text": false, "use_learnable_missing_text_gate": false, "use_learned_reliability_conditioning": false, "use_masked_fixed_denominator_joint_scoring": false, "use_missing_aware_conditioning": false, "use_missing_aware_film_conditioning": false, "use_missing_aware_fusion": false, "use_missing_aware_joint_scoring": false, "use_missing_mask": false, "use_missing_text_consistency": false, "use_missing_text_token_scale": false, "use_oracle_restore_injected_text": false, "use_prototype_missing_text": false, "use_side_aware_missing_text": true, "use_soft_missing_image": false, "use_soft_missing_text": true, "use_soft_token_text_generator_alignment": false, "use_structure_conditioned_missing_text": false, "use_text_loss_gating": false, "use_text_sampling_gating": false}}"""

SUMMARY_SPLITS = [
    ("overall", "Overall"),
    ("head_missing_text", "Head Missing Text"),
    ("tail_missing_text", "Tail Missing Text"),
    ("head_or_tail_missing_text", "Head/Tail Missing Text"),
    ("head_and_tail_have_text", "Head/Tail Both Have Text"),
]

METRICS = [
    ("mrr", "MRR"),
    ("mr", "MR"),
    ("hit10", "Hit@10"),
    ("hit3", "Hit@3"),
    ("hit1", "Hit@1"),
]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run MKG-Y side-aware soft missing-text experiments for seeds 1 and 2, then merge them with the provided seed-0 result."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--python-exe", type=str, default=sys.executable)
    parser.add_argument("--seeds", type=int, nargs="+", default=[1, 2])
    parser.add_argument("--checkpoint-template", type=str, default="./checkpoint/rotate_sideaware_seed{seed}.ckpt")
    parser.add_argument("--output-dir", type=str, default="./results")
    parser.add_argument("--seed0-json-path", type=str, default=None)
    parser.add_argument("--train-times", type=int, default=None)
    parser.add_argument("--no-subset-eval", action="store_true")
    return parser.parse_args()


def load_json_payload(json_text):
    cleaned_text = json_text.strip()
    try:
        return json.loads(cleaned_text, parse_constant=lambda _value: float("nan"))
    except json.JSONDecodeError as error:
        if error.msg != "Extra data":
            raise

    # Be tolerant to accidentally copied trailing braces in the embedded seed-0 payload.
    candidate_text = cleaned_text
    while candidate_text.endswith("}"):
        candidate_text = candidate_text[:-1].rstrip()
        try:
            return json.loads(candidate_text, parse_constant=lambda _value: float("nan"))
        except json.JSONDecodeError:
            continue
    raise


def load_seed0_result(seed0_json_path):
    if seed0_json_path is None:
        return load_json_payload(EMBEDDED_SEED0_RESULT_JSON)
    with open(seed0_json_path, "r", encoding="utf-8") as file:
        return json.load(file, parse_constant=lambda _value: float("nan"))


def extract_split_metrics(result_payload, split_name):
    if split_name == "overall":
        return result_payload["overall_metrics"]
    subset_metrics = result_payload.get("subset_metrics") or {}
    if split_name not in subset_metrics:
        raise KeyError(f"Missing subset metrics for '{split_name}' in seed {result_payload.get('seed')}")
    return subset_metrics[split_name]


def format_mean_std(values):
    mean_value = statistics.mean(values)
    std_value = statistics.stdev(values) if len(values) > 1 else 0.0
    return mean_value, std_value


def run_command(label, command):
    print(f"\n=== {label} ===", flush=True)
    print("Running:", " ".join(command), flush=True)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
        env=env,
    )

    captured_output = bytearray()
    assert process.stdout is not None
    while True:
        chunk = process.stdout.read(4096)
        if not chunk:
            break
        captured_output.extend(chunk)
        sys.stdout.buffer.write(chunk)
        sys.stdout.buffer.flush()

    return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)

    result_payload = None
    decoded_output = captured_output.decode("utf-8", errors="replace")
    for line in decoded_output.splitlines():
        if line.startswith("RESULT_JSON: "):
            result_payload = json.loads(line[len("RESULT_JSON: "):], parse_constant=lambda _value: float("nan"))
    if result_payload is None:
        raise RuntimeError(f"No RESULT_JSON captured for {label}")

    print(f"=== Completed: {label} ===", flush=True)
    return result_payload


def ensure_output_dir(path):
    os.makedirs(path, exist_ok=True)


def write_result_json(path, payload):
    with open(path, "w", encoding="utf-8") as file:
        json.dump(payload, file, ensure_ascii=False, indent=2, allow_nan=True)


def write_per_run_csv(path, results):
    with open(path, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["seed", "split", "mrr", "mr", "hit10", "hit3", "hit1"])
        for result in results:
            for split_name, split_label in SUMMARY_SPLITS:
                metrics = extract_split_metrics(result, split_name)
                writer.writerow([
                    result["seed"],
                    split_label,
                    metrics["mrr"],
                    metrics["mr"],
                    metrics["hit10"],
                    metrics["hit3"],
                    metrics["hit1"],
                ])


def write_summary_csv(path, results):
    with open(path, "w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["split", "metric", "mean", "std"])
        for split_name, split_label in SUMMARY_SPLITS:
            split_metrics = [extract_split_metrics(result, split_name) for result in results]
            for metric_key, metric_label in METRICS:
                mean_value, std_value = format_mean_std([metrics[metric_key] for metrics in split_metrics])
                writer.writerow([split_label, metric_label, mean_value, std_value])


def print_summary(results):
    print("\nPer-seed summary:")
    print("| Seed | Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---:|---|---:|---:|---:|---:|---:|")
    for result in results:
        for split_name, split_label in SUMMARY_SPLITS:
            metrics = extract_split_metrics(result, split_name)
            print(
                f"| {result['seed']} | {split_label} | {metrics['mrr']:.6f} | {metrics['mr']:.6f} | "
                f"{metrics['hit10']:.6f} | {metrics['hit3']:.6f} | {metrics['hit1']:.6f} |"
            )

    print("\n3-seed aggregate (mean +/- std):")
    print("| Split | MRR | MR | Hit@10 | Hit@3 | Hit@1 |")
    print("|---|---:|---:|---:|---:|---:|")
    for split_name, split_label in SUMMARY_SPLITS:
        split_metrics = [extract_split_metrics(result, split_name) for result in results]
        formatted_values = []
        for metric_key, _metric_label in METRICS:
            mean_value, std_value = format_mean_std([metrics[metric_key] for metrics in split_metrics])
            formatted_values.append(f"{mean_value:.6f} +/- {std_value:.6f}")
        print(
            f"| {split_label} | {formatted_values[0]} | {formatted_values[1]} | {formatted_values[2]} | {formatted_values[3]} | {formatted_values[4]} |"
        )


def main():
    args = parse_args()
    if args.dataset != "MKG-Y":
        raise ValueError("The embedded seed-0 result is for MKG-Y only. Please keep --dataset MKG-Y or provide --seed0-json-path.")

    ensure_output_dir(args.output_dir)

    all_results = []
    seed0_result = load_seed0_result(args.seed0_json_path)
    if int(seed0_result.get("seed", -1)) != 0:
        raise ValueError("Seed-0 result payload must have seed=0.")
    seed0_output_path = os.path.join(args.output_dir, "rotate_sideaware_seed0_result.json")
    write_result_json(seed0_output_path, seed0_result)
    all_results.append(seed0_result)

    for seed in args.seeds:
        command = [
            args.python_exe,
            "train_dhns_rotate.py",
            "--dataset",
            args.dataset,
            "--seed",
            str(seed),
            "--use-soft-missing-text",
            "--use-side-aware-missing-text",
            "--checkpoint-path",
            args.checkpoint_template.format(seed=seed),
        ]
        if not args.no_subset_eval:
            command.append("--subset-eval")
        if args.train_times is not None:
            command.extend(["--train-times", str(args.train_times)])

        label = f"Side-aware soft missing-text | seed={seed}"
        result_payload = run_command(label, command)
        output_json_path = os.path.join(args.output_dir, f"rotate_sideaware_seed{seed}_result.json")
        write_result_json(output_json_path, result_payload)
        all_results.append(result_payload)

    all_results.sort(key=lambda item: int(item["seed"]))
    per_run_csv_path = os.path.join(args.output_dir, "rotate_sideaware_seed012_runs.csv")
    summary_csv_path = os.path.join(args.output_dir, "rotate_sideaware_seed012_summary.csv")
    write_per_run_csv(per_run_csv_path, all_results)
    write_summary_csv(summary_csv_path, all_results)
    print_summary(all_results)
    print("\nSaved files:")
    print(f"  seed0_result_json: {os.path.abspath(seed0_output_path)}")
    for seed in args.seeds:
        print(f"  seed{seed}_result_json: {os.path.abspath(os.path.join(args.output_dir, f'rotate_sideaware_seed{seed}_result.json'))}")
    print(f"  per_run_csv: {os.path.abspath(per_run_csv_path)}")
    print(f"  summary_csv: {os.path.abspath(summary_csv_path)}")


if __name__ == "__main__":
    main()
