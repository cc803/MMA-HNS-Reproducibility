import argparse
import os

import numpy as np
import torch
from sklearn.cluster import KMeans


def parse_args():
    parser = argparse.ArgumentParser(
        description="Build offline cluster assignments for the Prototype Missing-Text Token Bank."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--num-clusters", type=int, default=64)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--n-init", type=int, default=10)
    parser.add_argument("--max-iter", type=int, default=300)
    parser.add_argument("--benchmark-path", type=str, default=None)
    parser.add_argument("--output-path", type=str, default=None)
    return parser.parse_args()


def resolve_benchmark_path(args):
    if args.benchmark_path is not None:
        return args.benchmark_path
    return os.path.join(".", "benchmarks", args.dataset)


def resolve_output_path(args):
    if args.output_path is not None:
        return args.output_path
    return os.path.join(resolve_benchmark_path(args), "prototype_missing_text_clusters.pt")


def read_count_file(path):
    with open(path, "r", encoding="utf-8") as file:
        first_line = file.readline().strip()
    return int(first_line)


def read_train_triples(path):
    with open(path, "r", encoding="utf-8") as file:
        triple_total = int(file.readline().strip())
        triples = []
        for line in file:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) != 3:
                raise ValueError(f"Invalid triple line in {path}: {line}")
            triples.append(tuple(int(part) for part in parts))
    if len(triples) != triple_total:
        raise ValueError(f"Triple count mismatch in {path}: header={triple_total}, parsed={len(triples)}")
    return triples


def build_features(benchmark_path):
    entity_total = read_count_file(os.path.join(benchmark_path, "entity2id.txt"))
    relation_total = read_count_file(os.path.join(benchmark_path, "relation2id.txt"))
    triples = read_train_triples(os.path.join(benchmark_path, "train2id.txt"))

    in_hist = np.zeros((entity_total, relation_total), dtype=np.float32)
    out_hist = np.zeros((entity_total, relation_total), dtype=np.float32)
    degree = np.zeros((entity_total,), dtype=np.float32)

    for head_id, tail_id, rel_id in triples:
        out_hist[head_id, rel_id] += 1.0
        in_hist[tail_id, rel_id] += 1.0
        degree[head_id] += 1.0
        degree[tail_id] += 1.0

    log_degree = np.log1p(degree).reshape(-1, 1)
    features = np.concatenate([in_hist, out_hist, log_degree], axis=1)
    return features, entity_total, relation_total, len(triples), degree


def main():
    args = parse_args()
    if args.num_clusters <= 0:
        raise ValueError("--num-clusters must be > 0.")
    if args.n_init <= 0:
        raise ValueError("--n-init must be > 0.")
    if args.max_iter <= 0:
        raise ValueError("--max-iter must be > 0.")

    benchmark_path = resolve_benchmark_path(args)
    output_path = resolve_output_path(args)
    features, entity_total, relation_total, triple_total, degree = build_features(benchmark_path)

    if args.num_clusters > entity_total:
        raise ValueError(
            f"--num-clusters ({args.num_clusters}) cannot exceed entity count ({entity_total})."
        )

    print("Prototype missing-text clustering:")
    print(f"  dataset: {args.dataset}")
    print(f"  benchmark_path: {os.path.abspath(benchmark_path)}")
    print(f"  entity_total: {entity_total}")
    print(f"  relation_total: {relation_total}")
    print(f"  triple_total: {triple_total}")
    print(f"  feature_dim: {features.shape[1]}")
    print(f"  num_clusters: {args.num_clusters}")
    print(f"  seed: {args.seed}")

    kmeans = KMeans(
        n_clusters=args.num_clusters,
        random_state=args.seed,
        n_init=args.n_init,
        max_iter=args.max_iter,
    )
    cluster_ids = kmeans.fit_predict(features)
    cluster_ids = torch.as_tensor(cluster_ids, dtype=torch.long)
    cluster_sizes = torch.bincount(cluster_ids, minlength=args.num_clusters)

    output_dir = os.path.dirname(output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    payload = {
        "dataset": args.dataset,
        "benchmark_path": os.path.abspath(benchmark_path),
        "entity_total": entity_total,
        "relation_total": relation_total,
        "triple_total": triple_total,
        "feature_dim": int(features.shape[1]),
        "feature_spec": [
            "in_relation_histogram",
            "out_relation_histogram",
            "log1p_degree",
        ],
        "num_clusters": args.num_clusters,
        "seed": args.seed,
        "n_init": args.n_init,
        "max_iter": args.max_iter,
        "cluster_ids": cluster_ids,
        "cluster_size_min": int(cluster_sizes.min().item()),
        "cluster_size_max": int(cluster_sizes.max().item()),
        "degree_mean": float(degree.mean()),
        "degree_max": float(degree.max()),
        "inertia": float(kmeans.inertia_),
    }
    torch.save(payload, output_path)

    print("Saved prototype cluster file:")
    print(f"  output_path: {os.path.abspath(output_path)}")
    print(f"  cluster_size_min: {payload['cluster_size_min']}")
    print(f"  cluster_size_max: {payload['cluster_size_max']}")
    print(f"  inertia: {payload['inertia']:.6f}")


if __name__ == "__main__":
    main()
