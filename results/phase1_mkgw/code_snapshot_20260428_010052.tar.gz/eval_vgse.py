import argparse
import json
import os
from collections import defaultdict

import numpy as np
import torch
from tqdm import tqdm

from mmkgc.module.model import AdvMixRotatE


def parse_args():
    parser = argparse.ArgumentParser(
        description="Validation-Guided Safe Score Ensemble for two trained AdvMixRotatE checkpoints."
    )
    parser.add_argument("--dataset", type=str, default="MKG-Y")
    parser.add_argument("--checkpoint-a", type=str, required=True)
    parser.add_argument("--checkpoint-b", type=str, required=True)
    parser.add_argument("--alpha-grid", type=str, default="0.0,0.1,0.2,0.3,0.4,0.5")
    parser.add_argument("--mode", type=str, choices=["global", "missingness_aware"], default="global")
    parser.add_argument("--subset-eval", action="store_true")
    parser.add_argument("--text-mode", type=str, choices=["soft_token"], default="soft_token")
    parser.add_argument("--retrieval-topk", type=int, default=5)
    parser.add_argument("--retrieval-pool-size", type=int, default=512)
    parser.add_argument("--retrieval-mix-weight", type=float, default=0.25)
    parser.add_argument("--no-gpu", action="store_true")
    return parser.parse_args()


def read_count(path):
    with open(path, "r", encoding="utf-8") as fin:
        return int(fin.readline().strip())


def read_triples(path):
    triples = []
    with open(path, "r", encoding="utf-8") as fin:
        lines = fin.readlines()[1:]
    for line in lines:
        parts = line.strip().split()
        if not parts:
            continue
        if len(parts) == 4:
            parts = parts[1:]
        h, t, r = map(int, parts[:3])
        triples.append((h, t, r))
    return triples


def build_filtered_maps(benchmark_path):
    all_triples = []
    for filename in ["train2id.txt", "valid2id.txt", "test2id.txt"]:
        all_triples.extend(read_triples(os.path.join(benchmark_path, filename)))
    hr_to_tails = defaultdict(set)
    tr_to_heads = defaultdict(set)
    for h, t, r in all_triples:
        hr_to_tails[(h, r)].add(t)
        tr_to_heads[(t, r)].add(h)
    return hr_to_tails, tr_to_heads


def summarize_missingness(img_emb, text_emb):
    has_text = text_emb.float().norm(dim=1).ne(0)
    has_image = img_emb.float().norm(dim=1).ne(0)
    return has_text, has_image


def parse_alpha_grid(alpha_grid):
    values = []
    for raw_value in alpha_grid.split(","):
        value = float(raw_value.strip())
        if value < 0.0 or value > 1.0:
            raise ValueError("--alpha-grid values must be in [0, 1].")
        values.append(value)
    if not values:
        raise ValueError("--alpha-grid must contain at least one value.")
    return values


def build_alpha_configs(alpha_grid, mode):
    if mode == "global":
        return [
            {
                "alpha": alpha,
                "alpha_missing": alpha,
                "alpha_complete": alpha,
            }
            for alpha in alpha_grid
        ]
    return [
        {
            "alpha": None,
            "alpha_missing": alpha_missing,
            "alpha_complete": alpha_complete,
        }
        for alpha_missing in alpha_grid
        for alpha_complete in alpha_grid
    ]


def make_model(args, img_emb, text_emb, has_text, has_image, ent_tot, rel_tot, use_retrieval_missing_text):
    return AdvMixRotatE(
        ent_tot=ent_tot,
        rel_tot=rel_tot,
        dim=512,
        margin=6.0,
        epsilon=2.0,
        img_emb=img_emb,
        text_emb=text_emb,
        has_text=has_text,
        original_has_text=has_text,
        has_image=has_image,
        use_soft_missing_text=True,
        use_retrieval_missing_text=use_retrieval_missing_text,
        retrieval_topk=args.retrieval_topk,
        retrieval_pool_size=args.retrieval_pool_size,
        retrieval_source="entity_embedding_knn",
        retrieval_mix_weight=args.retrieval_mix_weight,
    )


def load_checkpoint_compatible(model, checkpoint_path):
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
    state_dict = torch.load(checkpoint_path, map_location="cpu")
    shared_token = state_dict.get("missing_text_token")
    if shared_token is not None:
        if "missing_text_token_head" not in state_dict:
            state_dict["missing_text_token_head"] = shared_token.clone()
        if "missing_text_token_tail" not in state_dict:
            state_dict["missing_text_token_tail"] = shared_token.clone()
    expected_shapes = {
        "ent_embeddings.weight": model.ent_embeddings.weight.shape,
        "rel_embeddings.weight": model.rel_embeddings.weight.shape,
    }
    for key, expected_shape in expected_shapes.items():
        if key not in state_dict:
            raise ValueError(f"Checkpoint {checkpoint_path} is missing {key}.")
        if tuple(state_dict[key].shape) != tuple(expected_shape):
            raise ValueError(
                f"Checkpoint {checkpoint_path} has incompatible {key} shape: "
                f"expected {tuple(expected_shape)}, got {tuple(state_dict[key].shape)}."
            )
    model.load_state_dict(state_dict, strict=False)
    model.eval()
    return model


def to_tensor(array, use_gpu):
    tensor = torch.from_numpy(array).long()
    return tensor.cuda() if use_gpu else tensor


def predict_score(model, data, use_gpu):
    with torch.no_grad():
        return model.predict(
            {
                "batch_h": to_tensor(data["batch_h"], use_gpu),
                "batch_t": to_tensor(data["batch_t"], use_gpu),
                "batch_r": to_tensor(data["batch_r"], use_gpu),
                "mode": data["mode"],
            }
        )


def calc_filtered_rank(score, target_idx, filtered_ids):
    valid = np.ones(score.shape[0], dtype=bool)
    if filtered_ids:
        valid[list(filtered_ids)] = False
    valid[target_idx] = True
    target_score = score[target_idx]
    return int(np.sum(score[valid] < target_score)) + 1


def summarize_ranks(ranks):
    if len(ranks) == 0:
        return {
            "count": 0,
            "mrr": float("nan"),
            "mr": float("nan"),
            "hit10": float("nan"),
            "hit3": float("nan"),
            "hit1": float("nan"),
        }
    ranks = np.asarray(ranks, dtype=np.float64)
    return {
        "count": int(ranks.shape[0]),
        "mrr": float(np.mean(1.0 / ranks)),
        "mr": float(np.mean(ranks)),
        "hit10": float(np.mean(ranks <= 10)),
        "hit3": float(np.mean(ranks <= 3)),
        "hit1": float(np.mean(ranks <= 1)),
    }


def empty_eval_state(subset_eval):
    state = {
        "overall_ranks": [],
        "groups": {},
    }
    if subset_eval:
        state["groups"] = {
            "head_or_tail_missing_text": {"_ranks": [], "triple_count": 0},
            "head_and_tail_have_text": {"_ranks": [], "triple_count": 0},
        }
    return state


def alpha_for_query(config, query_has_missing_text):
    if query_has_missing_text:
        return config["alpha_missing"]
    return config["alpha_complete"]


def update_subset_state(state, ranks, h, t, has_text):
    if not state["groups"]:
        return
    head_has_text = bool(has_text[h])
    tail_has_text = bool(has_text[t])
    if (not head_has_text) or (not tail_has_text):
        state["groups"]["head_or_tail_missing_text"]["_ranks"].extend(ranks)
        state["groups"]["head_or_tail_missing_text"]["triple_count"] += 1
    else:
        state["groups"]["head_and_tail_have_text"]["_ranks"].extend(ranks)
        state["groups"]["head_and_tail_have_text"]["triple_count"] += 1


def finalize_eval_state(state):
    overall = summarize_ranks(state["overall_ranks"])
    overall["count_type"] = "query"
    overall["triple_count"] = int(len(state["overall_ranks"]) // 2)

    subset_metrics = {}
    for group_name, group_state in state["groups"].items():
        summary = summarize_ranks(group_state["_ranks"])
        summary["count_type"] = "query"
        summary["triple_count"] = int(group_state["triple_count"])
        subset_metrics[group_name] = summary
    if "head_and_tail_have_text" in subset_metrics:
        subset_metrics["head_or_tail_both_have_text"] = dict(subset_metrics["head_and_tail_have_text"])
    return overall, subset_metrics if subset_metrics else None


def make_candidate_batches(h, t, r, ent_tot):
    entity_ids = np.arange(ent_tot, dtype=np.int64)
    head_data = {
        "batch_h": entity_ids.copy(),
        "batch_t": np.asarray([t], dtype=np.int64),
        "batch_r": np.asarray([r], dtype=np.int64),
        "mode": "head_batch",
    }
    tail_data = {
        "batch_h": np.asarray([h], dtype=np.int64),
        "batch_t": entity_ids.copy(),
        "batch_r": np.asarray([r], dtype=np.int64),
        "mode": "tail_batch",
    }
    return head_data, tail_data


def evaluate_alpha_configs(
    model_a,
    model_b,
    triples,
    hr_to_tails,
    tr_to_heads,
    has_text,
    alpha_configs,
    use_gpu,
    subset_eval,
    split_name,
):
    ent_tot = model_a.ent_tot
    states = [empty_eval_state(subset_eval) for _ in alpha_configs]
    has_text_np = has_text.cpu().numpy().astype(bool)
    for h, t, r in tqdm(triples, desc=f"VGSE {split_name}", leave=False):
        head_data, tail_data = make_candidate_batches(h, t, r, ent_tot)
        head_a = predict_score(model_a, head_data, use_gpu)
        head_b = predict_score(model_b, head_data, use_gpu)
        tail_a = predict_score(model_a, tail_data, use_gpu)
        tail_b = predict_score(model_b, tail_data, use_gpu)
        query_has_missing_text = (not bool(has_text_np[h])) or (not bool(has_text_np[t]))
        head_filtered = tr_to_heads[(t, r)] - {h}
        tail_filtered = hr_to_tails[(h, r)] - {t}
        for config, state in zip(alpha_configs, states):
            alpha = alpha_for_query(config, query_has_missing_text)
            head_score = (1.0 - alpha) * head_b + alpha * head_a
            tail_score = (1.0 - alpha) * tail_b + alpha * tail_a
            head_rank = calc_filtered_rank(head_score, h, head_filtered)
            tail_rank = calc_filtered_rank(tail_score, t, tail_filtered)
            current_ranks = [head_rank, tail_rank]
            state["overall_ranks"].extend(current_ranks)
            update_subset_state(state, current_ranks, h, t, has_text_np)

    results = []
    for config, state in zip(alpha_configs, states):
        overall, subset_metrics = finalize_eval_state(state)
        results.append(
            {
                "alpha": config["alpha"],
                "alpha_missing": config["alpha_missing"],
                "alpha_complete": config["alpha_complete"],
                "overall_metrics": overall,
                "subset_metrics": subset_metrics,
            }
        )
    return results


def selection_key(result):
    metrics = result["overall_metrics"]
    alpha = result["alpha"] if result["alpha"] is not None else 0.0
    alpha_sum = result["alpha_missing"] + result["alpha_complete"]
    return (
        metrics["mrr"],
        metrics["hit10"],
        metrics["hit3"],
        metrics["hit1"],
        -metrics["mr"],
        -alpha_sum,
        -alpha,
    )


def compact_grid_result(result):
    return {
        "alpha": result["alpha"],
        "alpha_missing": result["alpha_missing"],
        "alpha_complete": result["alpha_complete"],
        "overall_mrr": result["overall_metrics"]["mrr"],
        "overall_hit10": result["overall_metrics"]["hit10"],
        "overall_mr": result["overall_metrics"]["mr"],
        "missing_text_mrr": (
            result["subset_metrics"]["head_or_tail_missing_text"]["mrr"]
            if result["subset_metrics"] and "head_or_tail_missing_text" in result["subset_metrics"] else None
        ),
        "both_have_text_mrr": (
            result["subset_metrics"]["head_and_tail_have_text"]["mrr"]
            if result["subset_metrics"] and "head_and_tail_have_text" in result["subset_metrics"] else None
        ),
    }


def print_metrics(title, metrics):
    print(title)
    print(f"  MRR: {metrics['mrr']:.6f}")
    print(f"  MR: {metrics['mr']:.6f}")
    print(f"  hit@10: {metrics['hit10']:.6f}")
    print(f"  hit@3: {metrics['hit3']:.6f}")
    print(f"  hit@1: {metrics['hit1']:.6f}")


def main():
    args = parse_args()
    alpha_grid = parse_alpha_grid(args.alpha_grid)
    benchmark_path = f"./benchmarks/{args.dataset}/"
    visual_path = f"./embeddings/{args.dataset}-visual.pth"
    textual_path = f"./embeddings/{args.dataset}-textual.pth"
    if not os.path.isdir(benchmark_path):
        raise FileNotFoundError(f"Dataset directory not found: {benchmark_path}")

    use_gpu = torch.cuda.is_available() and not args.no_gpu
    img_emb = torch.load(visual_path, map_location="cpu")
    text_emb = torch.load(textual_path, map_location="cpu")
    has_text, has_image = summarize_missingness(img_emb, text_emb)
    ent_tot = int(img_emb.shape[0])
    rel_tot = read_count(os.path.join(benchmark_path, "relation2id.txt"))
    if ent_tot != read_count(os.path.join(benchmark_path, "entity2id.txt")):
        raise ValueError("Embedding entity count does not match entity2id.txt.")

    print(
        "VGSE config | dataset=%s | mode=%s | alpha_grid=%s | checkpoint_a=%s | checkpoint_b=%s"
        % (args.dataset, args.mode, ",".join(str(a) for a in alpha_grid), args.checkpoint_a, args.checkpoint_b)
    )
    print("VGSE safety | training=False | new_network=False | score_level_linear_ensemble=True")

    model_a = make_model(
        args,
        img_emb,
        text_emb,
        has_text,
        has_image,
        ent_tot,
        rel_tot,
        use_retrieval_missing_text=False,
    )
    model_b = make_model(
        args,
        img_emb,
        text_emb,
        has_text,
        has_image,
        ent_tot,
        rel_tot,
        use_retrieval_missing_text=True,
    )
    load_checkpoint_compatible(model_a, args.checkpoint_a)
    load_checkpoint_compatible(model_b, args.checkpoint_b)
    if use_gpu:
        model_a.cuda()
        model_b.cuda()
    model_a.eval()
    model_b.eval()

    valid_triples = read_triples(os.path.join(benchmark_path, "valid2id.txt"))
    test_triples = read_triples(os.path.join(benchmark_path, "test2id.txt"))
    hr_to_tails, tr_to_heads = build_filtered_maps(benchmark_path)
    alpha_configs = build_alpha_configs(alpha_grid, args.mode)

    valid_results = evaluate_alpha_configs(
        model_a,
        model_b,
        valid_triples,
        hr_to_tails,
        tr_to_heads,
        has_text,
        alpha_configs,
        use_gpu,
        subset_eval=True,
        split_name="valid",
    )
    selected_result = max(valid_results, key=selection_key)
    selected_config = {
        "alpha": selected_result["alpha"],
        "alpha_missing": selected_result["alpha_missing"],
        "alpha_complete": selected_result["alpha_complete"],
    }
    print(
        "VGSE selected | mode=%s | alpha=%s | alpha_missing=%.3f | alpha_complete=%.3f | valid_mrr=%.6f"
        % (
            args.mode,
            "NA" if selected_config["alpha"] is None else "%.3f" % selected_config["alpha"],
            selected_config["alpha_missing"],
            selected_config["alpha_complete"],
            selected_result["overall_metrics"]["mrr"],
        )
    )

    test_results = evaluate_alpha_configs(
        model_a,
        model_b,
        test_triples,
        hr_to_tails,
        tr_to_heads,
        has_text,
        [selected_config],
        use_gpu,
        subset_eval=args.subset_eval,
        split_name="test",
    )
    test_result = test_results[0]
    print_metrics("VGSE test overall metrics:", test_result["overall_metrics"])
    if test_result["subset_metrics"] is not None:
        subset = test_result["subset_metrics"]
        if "head_or_tail_missing_text" in subset:
            print_metrics("VGSE test Head/Tail Missing Text:", subset["head_or_tail_missing_text"])
        if "head_and_tail_have_text" in subset:
            print_metrics("VGSE test Head/Tail Both Have Text:", subset["head_and_tail_have_text"])

    result_payload = {
        "dataset": args.dataset,
        "mode": args.mode,
        "checkpoint_a": args.checkpoint_a,
        "checkpoint_b": args.checkpoint_b,
        "alpha_grid": alpha_grid,
        "selected_alpha": selected_config["alpha"],
        "selected_alpha_missing": selected_config["alpha_missing"],
        "selected_alpha_complete": selected_config["alpha_complete"],
        "validation_selected_metrics": selected_result,
        "validation_grid": [compact_grid_result(result) for result in valid_results],
        "test_overall_metrics": test_result["overall_metrics"],
        "test_subset_metrics": test_result["subset_metrics"],
        "entity_count": ent_tot,
        "relation_count": rel_tot,
        "candidate_order": "entity_id_ascending_0_to_ent_tot_minus_1",
        "checkpoint_id_order_check": "state_dict entity/relation embedding shapes match dataset counts",
        "retrieval_topk": args.retrieval_topk,
        "retrieval_pool_size": args.retrieval_pool_size,
        "retrieval_mix_weight": args.retrieval_mix_weight,
        "disabled_training_side_modules": {
            "confidence_calibration": True,
            "relation_aware_retrieval": True,
            "gate_expert_router_imputer_training": True,
            "diffheg": True,
        },
    }
    print("RESULT_JSON: " + json.dumps(result_payload, sort_keys=True))


if __name__ == "__main__":
    main()
